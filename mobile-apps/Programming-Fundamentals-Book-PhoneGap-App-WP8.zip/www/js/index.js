var app = {

    // Application constructor
    initialize: function() {
        this.bindEvents();
    },

    // Bind event listeners
    //
    // Bind any events that are required on startup. Common events are:
    // `load`, `deviceready`, `offline`, and `online`.
    bindEvents: function() {
        document.addEventListener('deviceready', this.onDeviceReady, false);
    },

    // deviceready event handler
    //
    // The scope of `this` is the event. In order to call the `receivedEvent`
    // function, we must explicity call `app.receivedEvent(...);`
    onDeviceReady: function() {
        app.receivedEvent('deviceready');
    },

    // Process received events
    receivedEvent: function(id) {
        console.log('Received event: ' + id);
    }

};

$(document).ready(function () {
    resizeFonts();
    $('.learn-more').click(function () {
        $("#book-info").css('display', 'block');
        $(".learn-more").css('display', 'none');
    });
});

$(window).resize(function () {
    resizeFonts();
});

function resizeFonts() {
    var fontSize = $(".navigation-title").width() / 8.5;
    $(".navigation-title").css('font-size', fontSize + "px");
}
