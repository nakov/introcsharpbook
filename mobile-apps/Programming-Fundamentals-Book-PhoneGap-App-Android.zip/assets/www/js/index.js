$(document).ready(function () {
    resizeFonts();
    $('.learn-more').click(function () {
        $("#book-info").css('display', 'block');
        $(".learn-more").css('display', 'none');
    });
});

$(window).resize(function () {
    resizeFonts();
});

function resizeFonts() {
    var fontSize = $(".navigation-title").width() / 8.5;
    $(".navigation-title").css('font-size', fontSize + "px");
}
