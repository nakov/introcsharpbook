package nakov.introprogramming;

import org.apache.cordova.DroidGap;
import android.os.Bundle;

public class IntroCSharpBookActivity extends DroidGap {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.setIntegerProperty("splashscreen", R.drawable.splashscreen);
        super.onCreate(savedInstanceState);
        super.loadUrl("file:///android_asset/www/index.html");
    }
}
