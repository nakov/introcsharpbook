package javaBook;

import java.awt.Color;
import java.awt.Container;
import java.awt.GridBagLayout;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.WindowConstants;

public class getContent {
	public void getCont(String i) {
		String driverName = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://localhost/";

		String dbName = "nakovorg_new_introprogramming?useUnicode=true&characterEncoding=utf-8";
		String userName = "root";
		String password = "";

		Connection con;
		Statement stmt;
		try {
			Class.forName(driverName).newInstance();
			con = DriverManager.getConnection(url + dbName, userName, password);
			try {
				PrintWriter writer = new PrintWriter(
						"C:\\Project\\JavaBook\\rltest.html", "UTF-8");
				stmt = con.createStatement();
				//AND post_title NOT LIKE '%Заключение%' AND (guid LIKE '%intro-java-book/read-online/%')
				String query = "SELECT post_content FROM posts WHERE post_title NOT LIKE '%Предговор%' AND ID = '"
						+ i + "' ";
				ResultSet rs = stmt.executeQuery(query);
				while (rs.next()) {
					String postContent = rs.getString("post_content");
					writer.println(postContent);
				}
				stmt.close();
				writer.close();

			} catch (SQLException s) {
				JFrame f = new JFrame("Selecting error!");
				f.setSize(400, 150);
				f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
				Container content = f.getContentPane();
				content.setBackground(Color.white);
				content.setLayout(new GridBagLayout());
				content.add(new JLabel(
						"An error occured while selecting with ID" + i + "!"));
				f.setLocationRelativeTo(null);
				f.setVisible(true);
				s.printStackTrace();
			}

			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
