package javaBook;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class insertInfo {
	int globalFlag = 0;

	@SuppressWarnings("resource")
	public boolean checkForContent() {
		try {
			File fileDir = new File("C:\\Project\\JavaBook\\rltest.html");
			BufferedReader in = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir), "UTF8"));

			String str;
			PrintWriter writer = new PrintWriter("C:\\Project\\JavaBook\\withSpace.html",
					"UTF-8");
			while ((str = in.readLine()) != null) {
				if (str.contains("<h2 id=\"table-of-contents\" style=\"margin: 12pt 0cm 6pt;\"><span lang=\"BG\" style=\"font-family: Verdana; font-size: 14pt; color: #000000; font-weight: bold;\">Съдържание</span></h2>")) {
					return false;
				}
			}
			writer.close();
			in.close();
			System.out.println("No errors found and can continue!");
		} catch (UnsupportedEncodingException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return true;
	}

	public void insertLine() {
		try {
			File fileDir = new File("C:\\Project\\JavaBook\\rltest.html");
			BufferedReader in = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir), "UTF8"));

			String str;
			PrintWriter writer = new PrintWriter("C:\\Project\\JavaBook\\withSpace.html",
					"UTF-8");
			while ((str = in.readLine()) != null) {
				if (str.contains("<div class=\"WordSection1\">")) {
					String code = str.substring(str.indexOf("<div"),
							str.indexOf("WordSection1\">"));
					str = str.replace(code, "");
					str = str.replace("WordSection1\">", "");
					globalFlag = 1;
				}
				if (str.contains("<h2")) {
					Pattern pattern = Pattern.compile("<h2(.*?)>");
					Matcher matcher = pattern.matcher(str);
					matcher.find();
					String newline = System.getProperty("line.separator");
					str = str.replace("<h2", "");
					str = str.replace(matcher.group(1), newline + "<h2"
							+ matcher.group(1));
					str = str.replaceFirst("\n", "");
					writer.println(str);
				}
			}
			writer.close();
			in.close();
			System.out.println("New line added successfully!");
		} catch (UnsupportedEncodingException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public void getWithSpaces() {

		try {
			File fileDir = new File("C:\\Project\\JavaBook\\withSpace.html");

			BufferedReader in = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir), "UTF8"));

			String str;
			PrintWriter writer = new PrintWriter("C:\\Project\\JavaBook\\done3.html",
					"UTF-8");
			writer.println("<h2 id=\"table-of-contents\" style=\"margin: 12pt 0cm 6pt;\"><span lang=\"BG\" style=\"font-family: Verdana; font-size: 14pt; color: #000000; font-weight: bold;\">Съдържание</span></h2>"
					+ "\n<ul>");
			while ((str = in.readLine()) != null) {
				if (str.contains("<h2")) {
					String code = str.substring(str.indexOf("<h2"),
							str.indexOf("<a name=\"_"));
					str = str.replace(code, " ");
					str = str.replace("<a name=\"_", "");
					String code2 = str.substring(str.indexOf(" "),
							str.indexOf("\">"));
					code2 = code2.replace(" ", "");
					writer.print("<li><a href=\"#_" + code2 + "\">");
				}

				if (str.contains("</h2>")) {
					String code = str.substring(str.indexOf(""),
							str.indexOf("</h2>"));
					if (code.contains("bold\">")) {
						Pattern p = Pattern.compile("bold\">(.*?)</font>");
						Matcher m = p.matcher(code);

						while (m.find()) {
							writer.print(m.group(1));
						}
						writer.print("</a></li>");
						writer.print("\n");
					} else {
						if (code.contains("bold;\">")) {
							Pattern p = Pattern.compile("bold;\">(.*?)</font>");
							Matcher m = p.matcher(code);

							while (m.find()) {
								writer.print(m.group(1));
							}
							writer.print("</a></li>");
							writer.print("\n");
						}
					}
				}
			}
			writer.println("<li><a href=\"#discussion-forum\">Дискусионен форум</a></li>"
					+ "\n</ul>");
			writer.close();
			in.close();
			System.out
					.println("The content from the file was taken successfully!");
		} catch (UnsupportedEncodingException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public void printContent() {
		Vector<String> lineArray = new Vector<String>();
		String lineContents = null;
		try {
			File fileDir2 = new File("C:\\Project\\JavaBook\\done3.html");

			BufferedReader br = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir2), "UTF8"));
			while ((lineContents = br.readLine()) != null) {
				lineArray.add(lineContents);
			}
			br.close();
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
		try {
			File fileDir = new File("C:\\Project\\JavaBook\\rltest.html");

			PrintWriter writer = new PrintWriter("C:\\Project\\JavaBook\\Info.html",
					"UTF-8");
			BufferedReader in = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir), "UTF8"));

			String str;
			str = in.readLine();
			int count = 0;
			int flag = 0;
			while (flag == 1) {
				if (str.contains("<div class=\"WordSection1\">")) {
					String code = str.substring(str.indexOf("<div"),
							str.indexOf("WordSection1\">"));
					str = str.replace(code, "");
					str = str.replace("WordSection1\">", "");
					writer.write(str);
					flag = 1;
					globalFlag = 1;
				}
			}
			do {
				if (str.contains("<b>")) {
					String code = str.substring(str.indexOf("<"),
							str.indexOf("<b>"));
					writer.write(code);
					count = 1;
				} else {
					if (str.contains("<b ")) {

						String code = str.substring(str.indexOf("<"),
								str.indexOf("<b "));
						writer.write(code);
						count = 1;
					}
				}
			} while (((str == "<b>") || (str == "<b ")) && (count == 1));

			for (int i = 0; i < lineArray.size(); i++) {
				writer.write(lineArray.get(i));
			}
			do {
				if (str.contains("<b>")) {
					String code = str.substring(str.indexOf("<b>"));
					writer.write(code);
				} else {
					if (str.contains("<b ")) {
						String code = str.substring(str.indexOf("<b "));
						writer.write(code);
					}
				}
			} while ((str == null) && (count == 1));
			writer.close();
			in.close();
			System.out.println("Content printed successfully!");
		} catch (UnsupportedEncodingException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public void printLast() {
		try {
			File fileDir = new File("C:\\Project\\JavaBook\\Info.html");

			PrintWriter writer = new PrintWriter("C:\\Project\\JavaBook\\withInfo.html",
					"UTF-8");
			BufferedReader in = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir), "UTF8"));
			String str;
			int finalRow = 0;
			while ((str = in.readLine()) != null) {
				if (!str.contains("\n<h2 id=\"discussion-forum\" style=\"margin: 12pt 0cm 6pt;\"><span lang=\"BG\" style=\"font-family: Verdana; font-size: 14pt; color: #000000; font-weight: bold;\">Дискусионен форум</span></h2>"
						+ "<span style=\"font-family: Verdana; font-size: 10pt;\">Коментирайте книгата и задачите в нея във: <a href=\"http://forums.academy.telerik.com\" target=\"_blank\">форума на софтуерната академия</a>.</span>")) {
					if (str.contains("</div>") && globalFlag == 1) {
						StringBuilder b = new StringBuilder(str);
						b.replace(
								str.lastIndexOf("</div>"),
								str.lastIndexOf("</div>") + 6,
								"\n<h2 id=\"discussion-forum\" style=\"margin: 12pt 0cm 6pt;\"><span lang=\"BG\" style=\"font-family: Verdana; font-size: 14pt; color: #000000; font-weight: bold;\">Дискусионен форум</span></h2>"
								+ "<span style=\"font-family: Verdana; font-size: 10pt;\">Коментирайте книгата и задачите в нея във: <a href=\"http://forums.academy.telerik.com\" target=\"_blank\">форума на софтуерната академия</a>.</span>"
								+ "</div>");
						str = b.toString();
						writer.println(str);
						finalRow = 0;
					} else {
						finalRow = 1;
						writer.println(str);
					}
				}

			}
			if (finalRow == 1) {
				writer.println("\n<h2 id=\"discussion-forum\" style=\"margin: 12pt 0cm 6pt;\"><span lang=\"BG\" style=\"font-family: Verdana; font-size: 14pt; color: #000000; font-weight: bold;\">Дискусионен форум</span></h2>"
						+ "<span style=\"font-family: Verdana; font-size: 10pt;\">Коментирайте книгата и задачите в нея във: <a href=\"http://forums.academy.telerik.com\" target=\"_blank\">форума на софтуерната академия</a>.</span>");
			}
			writer.close();
			in.close();
			System.out.println("Last line added successfully!");
		} catch (UnsupportedEncodingException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public void fixCode() {
		try {
			File fileDir = new File("C:\\Project\\JavaBook\\withInfo.html");
			BufferedReader in = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir), "UTF8"));

			String str;
			PrintWriter writer = new PrintWriter(
					"C:\\Project\\JavaBook\\withInfoFinal.html", "UTF-8");
			while ((str = in.readLine()) != null) {
				String str2;
				str2 = "&nbsp;&nbsp;&nbsp";
				String str3;
				str3 = "<p style=\"margin: 0cm 0cm 0pt\" class=\"MsoNormal\" align=\"center\">";
				String str4;
				str4 = "width=\"712\"";
				String str5;
				str5 = "<p style=\"text-align:center;margin:0\">";
				if (str.contains("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp")) {
					str = str.replaceAll("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp", str2);
					System.out.println("Now we have 3 spaces");
				}
				if (str.contains("width=\"531\"")) {
					str = str.replaceAll("width=\"531\"", str4);
					System.out.println("Width 531 changed to 712");
				}
				if (str.contains("width=\"481\"")) {
					str = str.replaceAll("width=\"481\"", str4);
					System.out.println("Width 481 changed to 712");
				}
				if (str.contains("width=\"492\"")) {
					str = str.replaceAll("width=\"492\"", str4);
					System.out.println("Width 492 changed to 712");
				}
				if (str.contains("width=\"477\"")) {
					str = str.replaceAll("width=\"477\"", str4);
					System.out.println("Width 477 changed to 712");
				}
				if (str.contains(str3)) {
					str = str.replaceAll(str3, str5);
					System.out.println("It should be centered now");
				}
				if (str.contains("width=\"507\"")) {
					str = str.replaceAll("width=\"507\"", str4);
					System.out.println("Width 507 changed to 712");
				}
				if (str.contains("width=\"536\"")) {
					str = str.replaceAll("width=\"536\"", str4);
					System.out.println("Width 536 changed to 712");
				}
				if (str.contains("width=\"528\"")) {
					str = str.replaceAll("width=\"528\"", str4);
					System.out.println("Width 528 changed to 712");
				}
				if (str.contains("width=\"600\"")) {
					str = str.replaceAll("width=\"600\"", str4);
					System.out.println("Width 600 changed to 712");
				}
				if (str.contains("width=\"483\"")) {
					str = str.replaceAll("width=\"483\"", str4);
					System.out.println("Width 483 changed to 712");
				}
				if (str.contains("width=\"612\"")) {
					str = str.replaceAll("width=\"612\"", str4);
					System.out.println("Width 612 changed to 712");
				}
				if (str.contains("width=\"529\"")) {
					str = str.replaceAll("width=\"529\"", str4);
					System.out.println("Width 529 changed to 712");
				}
				if (str.contains("width=\"500\"")) {
					str = str.replaceAll("width=\"500\"", str4);
					System.out.println("Width 500 changed to 712");
				}
				if (str.contains("width=\"528\"")) {
					str = str.replaceAll("width=\"528\"", str4);
					System.out.println("Width 528 changed to 712");
				}
				if (str.contains("width=\"506\"")) {
					str = str.replaceAll("width=\"506\"", str4);
					System.out.println("Width 506 changed to 712");
				}
				if (str.contains("width=\"504\"")) {
					str = str.replaceAll("width=\"504\"", str4);
					System.out.println("Width 504 changed to 712");
				}
				if (str.contains("width=\"505\"")) {
					str = str.replaceAll("width=\"505\"", str4);
					System.out.println("Width 505 changed to 712");
				}
				if (str.contains("width=\"530\"")) {
					str = str.replaceAll("width=\"530\"", str4);
					System.out.println("Width 530 changed to 712");
				}
				if (str.contains("width=\"502\"")) {
					str = str.replaceAll("width=\"502\"", str4);
					System.out.println("Width 502 changed to 712");
				}
				writer.write(str);
			}
			writer.close();
			in.close();
			System.out.println("Code fixed successfully!\n");
		} catch (UnsupportedEncodingException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	@SuppressWarnings("resource")
	public boolean checkForErrors() {
		try {
			File fileDir = new File("C:\\Project\\JavaBook\\ErrorCheck.txt");
			BufferedReader in = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir), "UTF8"));

			String str;
			while ((str = in.readLine()) != null) {
				if (str.contains("String index out of range")
						|| str.contains("null")) {
					return false;
				}
			}
			in.close();
		} catch (UnsupportedEncodingException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return true;
	}
}