package javaLinksExternal;

import java.awt.Color;
import java.awt.Container;
import java.awt.GridBagLayout;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.WindowConstants;

public class PutBackLinks {
	public void putCont(String i) {
		String driverName = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://localhost/";

		String dbName = "nakovorg_new_introprogramming?useUnicode=true&characterEncoding=utf-8";
		String userName = "root";
		String password = "";

		Connection con;
		try {
			Class.forName(driverName).newInstance();
			con = DriverManager.getConnection(url + dbName, userName, password);
			try {

				File fileDir = new File(
						"C:\\Project\\Links\\JavaAllFinal\\FinalContent.html");
				BufferedReader in = new BufferedReader(new InputStreamReader(
						new FileInputStream(fileDir), "UTF8"));

				String str;
				//WHERE post_content LIKE '%file:%' AND post_title LIKE '%Chapter%'
				String query = "UPDATE posts SET post_content = ? WHERE (post_title LIKE '%Глава%') AND post_type = 'page' AND post_parent = '26' AND ID = '"
						+ i + "'";
				PreparedStatement preparedStmt = con.prepareStatement(query);
				while ((str = in.readLine()) != null) {
					preparedStmt.setString(1, str);
				}
				preparedStmt.executeUpdate();
				in.close();
			} catch (SQLException s) {
				JFrame f = new JFrame("Putting new content error!");
				f.setSize(400, 150);
				f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
				Container content = f.getContentPane();
				content.setBackground(Color.white);
				content.setLayout(new GridBagLayout());
				content.add(new JLabel(
						"An error occured while updating the ID " + i + "!"));
				f.setLocationRelativeTo(null);
				f.setVisible(true);
				s.printStackTrace();
			}

			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
