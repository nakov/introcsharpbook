package javaLinksExternal;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FixJavaLinks {
	int globalFlag = 0;

	public void GetLinks() {
		try {
			File fileDir2 = new File(
					"C:\\Project\\Links\\JavaAllFinal\\Content.html");
			BufferedReader br2 = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir2), "UTF8"));
			PrintWriter writer = new PrintWriter(
					"C:\\Project\\Links\\JavaAllFinal\\FoundLinks.txt", "UTF-8");
			String str;
			while ((str = br2.readLine()) != null) {
				if (str.contains("<a href=\"#_")) {
					Pattern pattern = Pattern.compile("<a href=\"#_(.*?)\"");
					Matcher matcher = pattern.matcher(str);
					globalFlag = 1;
					while (matcher.find()) {
						writer.println("///C:/test/#_" + matcher.group(1));
					}
				}
			}
			br2.close();
			writer.close();
			System.out.println("Links are found!Program can continue now.");
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
	}

	public void TempContent() {
		try {
			File fileDir = new File(
					"C:\\Project\\Links\\JavaAllFinal\\Content.html");
			BufferedReader br = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir), "UTF8"));
			PrintWriter writer = new PrintWriter(
					"C:\\Project\\Links\\JavaAllFinal\\TempContent.html",
					"UTF-8");
			String str;
			while ((str = br.readLine()) != null) {
				if (str.contains("<a href=\"#_")) {
					str = str.replace("<a href=\"#_", "\n<a href=\"#_");
				}
				writer.write(str);
			}
			br.close();
			writer.close();
			System.out
					.println("Temp content is ready!Program can continue now.");
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
	}

	public void TempContentSpace() {
		try {
			File fileDir = new File(
					"C:\\Project\\Links\\JavaAllFinal\\TempContent.html");
			BufferedReader br = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir), "UTF8"));
			PrintWriter writer = new PrintWriter(
					"C:\\Project\\Links\\JavaAllFinal\\TempContentSpace.html",
					"UTF-8");
			String str;
			while ((str = br.readLine()) != null) {
				if (str.contains("<a href=\"#_")) {
					String code2 = str.substring(str.indexOf("<a href=\"#_"),
							str.indexOf("\">"));
					str = str.replace(code2, "TempLine");
				}
				writer.println(str);
			}
			br.close();
			writer.close();
			System.out
					.println("Temp content with space is ready!Program can continue now.");
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
	}

	public void FixAllLinks() {
		try {
			File fileDir2 = new File(
					"C:\\Project\\Links\\JavaAllFinal\\FoundLinks.txt");
			BufferedReader br2 = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir2), "UTF8"));
			PrintWriter writer = new PrintWriter(
					"C:\\Project\\Links\\JavaAllFinal\\FixedLinks.txt", "UTF-8");
			String str;
			while ((str = br2.readLine()) != null) {
				if (Pattern
						.compile(Pattern.quote("test"),
								Pattern.CASE_INSENSITIVE).matcher(str).find()) {
					Pattern pattern = Pattern.compile("///(.*?)/#");
					Matcher matcher = pattern.matcher(str);
					while (matcher.find()) {
						str = str.replaceAll("///(.*?)/#",
								"/intro-java-book/read-online/#");
						writer.println(str);
					}
				}
			}
			br2.close();
			writer.close();
			System.out.println("Links are fixed!Program can continue now.");
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
	}

	public void FixNumbers() {
		try {
			File fileDir2 = new File(
					"C:\\Project\\Links\\JavaAllFinal\\FixedLinks.txt");
			BufferedReader br2 = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir2), "UTF8"));
			PrintWriter writer2 = new PrintWriter(
					"C:\\Project\\Links\\JavaAllFinal\\FixLinesPreFinal.txt",
					"UTF-8");
			String str;
			while ((str = br2.readLine()) != null) {
				if (str.contains("/#")) {
					String temp = str.substring(str.indexOf("/"),
							str.indexOf("#"));
					str = str.replace(temp, "");
					writer2.println(str);
				}
			}
			br2.close();
			writer2.close();
			System.out
					.println("Numbers and lines are done!Program can continue now.");
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
	}

	public void FixLinesFinal() {
		Vector<String> lineArray = new Vector<String>();
		String lineContents = null;
		try {
			File fileDir = new File(
					"C:\\Project\\Links\\JavaAllFinal\\FixLinesPreFinal.txt");

			BufferedReader br = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir), "UTF8"));
			while ((lineContents = br.readLine()) != null) {
				lineArray.add(lineContents);
			}
			br.close();
			PrintWriter writer = new PrintWriter(
					"C:\\Project\\Links\\JavaAllFinal\\FixLines.txt", "UTF-8");
			for (int i = 0; i < lineArray.size(); i++) {
				File fileDir2 = new File(
						"C:\\Project\\Links\\JavaAllFinal\\FixedExternal.txt");
				BufferedReader br2 = new BufferedReader(new InputStreamReader(
						new FileInputStream(fileDir2), "UTF8"));
				String str;
				while ((str = br2.readLine()) != null) {
					if (str.contains(lineArray.get(i))) {
						writer.println(str);
						break;
					}
				}
				br2.close();
			}
			writer.close();
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
	}

	public void FinalContent() {
		Vector<String> lineArray = new Vector<String>();
		String lineContents = null;
		try {
			File lineDir = new File(
					"C:\\Project\\Links\\JavaAllFinal\\FixLines.txt");

			BufferedReader lineBr = new BufferedReader(new InputStreamReader(
					new FileInputStream(lineDir), "UTF8"));
			while ((lineContents = lineBr.readLine()) != null) {
				lineArray.add(lineContents);
			}
			lineBr.close();
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
		try {
			File fileDir = new File(
					"C:\\Project\\Links\\JavaAllFinal\\TempContentSpace.html");
			BufferedReader br = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir), "UTF8"));
			PrintWriter writer = new PrintWriter(
					"C:\\Project\\Links\\JavaAllFinal\\FinalContent.html",
					"UTF-8");
			String str;
			int c = 0;
			while ((str = br.readLine()) != null) {
				if (str.contains("TempLine")) {
					String code = str.substring(str.indexOf("TempLine"),
							str.indexOf("\">"));
					str = str.replace(code, "<a href=\"" + lineArray.get(c));
					c++;
				}
				writer.write(str);
			}
			br.close();
			writer.close();
			System.out
					.println("Final content is ready to be used!Program can continue now.");
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
	}

	@SuppressWarnings("resource")
	public boolean checkForErrors() {
		try {
			File fileDir = new File(
					"C:\\Project\\Links\\JavaAllFinal\\ErrorCheck.txt");
			BufferedReader in = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir), "UTF8"));

			String str;
			while ((str = in.readLine()) != null) {
				if (str.contains("String index out of range")
						|| str.contains("null")
						|| str.contains("Array index out of range")) {
					return false;
				}
			}
			if (globalFlag == 0) {
				return false;
			}
			in.close();
		} catch (UnsupportedEncodingException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return true;
	}
}
