package testLinks;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PrintLinks {
	public void putInFile(String s) {
		try {
			File fileDir = new File("C:\\Project\\Links\\rltest.html");
			BufferedReader in = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir), "UTF8"));

			String str;
			FileOutputStream file = new FileOutputStream(
					"C:\\Project\\Links\\AllLinks.txt", true);
			BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(
					file, "UTF8"));
			writer.write(s+"\n");
			while ((str = in.readLine()) != null) {
				if (str.contains("<a href=\"file:")) {
					Pattern pattern = Pattern.compile("<a href=\"file:(.*?)>");
					Matcher matcher = pattern.matcher(str);
					while(matcher.find()) {
						writer.write(matcher.group(1) + "\n");
					}
				}
			}
			writer.write("\n");
			writer.close();
			in.close();
			System.out.println("Links added successfully!");
		} catch (UnsupportedEncodingException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
