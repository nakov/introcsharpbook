package testLinks;

import java.awt.Color;
import java.awt.Container;
import java.awt.GridBagLayout;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.WindowConstants;

public class GetChapters {
	public void getChapters() {
		String driverName = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://localhost/";

		String dbName = "nakovorg_new_introprogramming?useUnicode=true&characterEncoding=utf-8";
		String userName = "root";
		String password = "";

		Connection con;
		Statement stmt;
		try {
			Class.forName(driverName).newInstance();
			con = DriverManager.getConnection(url + dbName, userName, password);
			try {
				stmt = con.createStatement();
				FileOutputStream file = new FileOutputStream(
						"C:\\Project\\Links\\OnlyChapters.txt", true);
				FileOutputStream file2 = new FileOutputStream(
						"C:\\Project\\Links\\Chapters.txt", true);
				BufferedWriter writer = new BufferedWriter(
						new OutputStreamWriter(file, "UTF8"));
				BufferedWriter writer2 = new BufferedWriter(
						new OutputStreamWriter(file2, "UTF8"));
				//SELECT * FROM `posts` WHERE post_content LIKE '%file:%' AND (guid LIKE '%intro-csharp-book/read-online/%' OR guid LIKE '%intro-java-book/read-online/%') AND (post_title LIKE '%Глава%' OR post_title LIKE '%Chapter%') ORDER BY  `posts`.`post_title` ASC
				String query2 = "SELECT * FROM `posts` WHERE post_content LIKE '%file:%' AND post_title LIKE '%Chapter%' ORDER BY  `posts`.`post_title` ASC";
				ResultSet rs2 = stmt.executeQuery(query2);
				while (rs2.next()) {
					String postContent = rs2.getString("post_title");
					String postBooks = rs2.getString("guid");
					writer.write(postContent + "\n");
					writer2.write(postContent + " " + postBooks + "\n");
				}
				stmt.close();
				writer.close();
				writer2.close();
			} catch (SQLException s) {
				JFrame f = new JFrame("Selecting error!");
				f.setSize(400, 150);
				f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
				Container content = f.getContentPane();
				content.setBackground(Color.white);
				content.setLayout(new GridBagLayout());
				content.add(new JLabel("An error occured while selecting!"));
				f.setLocationRelativeTo(null);
				f.setVisible(true);
				s.printStackTrace();
			}

			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
