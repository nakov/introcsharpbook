package javaLinks;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class JavaFixLinks {
	public void GetLinks() {
		try {
			File fileDir2 = new File("C:\\Project\\Links\\Content.html");
			BufferedReader br2 = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir2), "UTF8"));
			PrintWriter writer = new PrintWriter(
					"C:\\Project\\Links\\FoundLinks.txt", "UTF-8");
			String str;
			while ((str = br2.readLine()) != null) {
				if (str.contains("file:")) {
					Pattern pattern = Pattern.compile("file:(.*?)\"");
					Matcher matcher = pattern.matcher(str);
					while (matcher.find()) {
						writer.println(matcher.group(1));
					}
				}
			}
			br2.close();
			writer.close();
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
	}

	public void FixAllLinks() {
		try {
			File fileDir2 = new File("C:\\Project\\Links\\FoundLinks.txt");
			BufferedReader br2 = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir2), "UTF8"));
			PrintWriter writer = new PrintWriter(
					"C:\\Project\\Links\\FixedLinks.txt", "UTF-8");
			String str;
			while ((str = br2.readLine()) != null) {
				if (Pattern
						.compile(Pattern.quote("Intro Java Book"),
								Pattern.CASE_INSENSITIVE).matcher(str).find()) {
					Pattern pattern = Pattern.compile("///(.*?)/#");
					Matcher matcher = pattern.matcher(str);
					while (matcher.find()) {
						str = str.replaceAll("///(.*?)/#",
								"/intro-java-book/read-online/#");
						writer.println(str);
					}
				}
				if (Pattern
						.compile(Pattern.quote("Intro C# Book"),
								Pattern.CASE_INSENSITIVE).matcher(str).find()) {
					Pattern pattern = Pattern.compile("///(.*?)/#");
					Matcher matcher = pattern.matcher(str);
					while (matcher.find()) {
						str = str.replaceAll("///(.*?)/#",
								"/intro-csharp-book/read-online/#");
						writer.println(str);
					}
				}
			}
			br2.close();
			writer.close();
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
	}

	public void FixNumbers() {
		try {
			File fileDir2 = new File("C:\\Project\\Links\\FixedLinks.txt");
			BufferedReader br2 = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir2), "UTF8"));
			PrintWriter writer = new PrintWriter(
					"C:\\Project\\Links\\FixedNumbers.txt", "UTF-8");
			String str;
			while ((str = br2.readLine()) != null) {
				if (str.contains("#_")) {
					Pattern pattern = Pattern.compile("(\\d+).");
					Matcher matcher = pattern.matcher(str);
					while(matcher.find()) {
						writer.println(matcher.group().replace(".", ""));
					}
				}
			}
			br2.close();
			writer.close();
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
	}
	public void GetNumbers() {
		try {
			File fileDir2 = new File("C:\\Project\\Links\\FixedNumbers.txt");
			BufferedReader br2 = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir2), "UTF8"));
			PrintWriter writer = new PrintWriter(
					"C:\\Project\\Links\\FixedAll.txt", "UTF-8");
			String str;
			
			while ((str = br2.readLine()) != null) {
				
			}
			br2.close();
			writer.close();
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
	}
}
