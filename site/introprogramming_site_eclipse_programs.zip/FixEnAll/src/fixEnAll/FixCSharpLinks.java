package fixEnAll;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FixCSharpLinks {
	int globalFlag = 0;

	public void GetLinks() {
		try {
			File fileDir2 = new File(
					"C:\\Project\\Links\\EnCSharpAll\\Content.html");
			BufferedReader br2 = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir2), "UTF8"));
			PrintWriter writer = new PrintWriter(
					"C:\\Project\\Links\\EnCSharpAll\\FoundLinks.txt", "UTF-8");
			String str;
			while ((str = br2.readLine()) != null) {
				if ((str.contains("<a href=\"file:") && str.contains("/#"))
						|| str.contains("<a href=\"#")) {
					Pattern pattern = Pattern.compile("<a href=\"file:(.*?)\"");
					Matcher matcher = pattern.matcher(str);
					Pattern pattern2 = Pattern.compile("<a href=\"#(.*?)\"");
					Matcher matcher2 = pattern2.matcher(str);
					globalFlag = 1;
					while (matcher.find()) {
						writer.println(matcher.group(1));
					}
					while (matcher2.find()) {
						writer.println("///C:/test/#" + matcher2.group(1));
					}
				}
			}
			br2.close();
			writer.close();
			System.out.println("Links are found!Program can continue now.");
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
	}

	public void TempContent() {
		try {
			File fileDir = new File(
					"C:\\Project\\Links\\EnCSharpAll\\Content.html");
			BufferedReader br = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir), "UTF8"));
			PrintWriter writer = new PrintWriter(
					"C:\\Project\\Links\\EnCSharpAll\\TempContent.html",
					"UTF-8");
			String str;
			while ((str = br.readLine()) != null) {
				if (str.contains("<a href=\"file:")) {
					str = str.replace("<a href=\"file:", "\n<a href=\"file:");
				}
				if (str.contains("<a href=\"#")) {
					str = str.replace("<a href=\"#", "\n<a href=\"#");
				}
				writer.write(str);
			}
			br.close();
			writer.close();
			System.out
					.println("Temp content is ready!Program can continue now.");
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
	}

	public void TempContentSpace() {
		try {
			File fileDir = new File(
					"C:\\Project\\Links\\EnCSharpAll\\TempContent.html");
			BufferedReader br = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir), "UTF8"));
			PrintWriter writer = new PrintWriter(
					"C:\\Project\\Links\\EnCSharpAll\\TempContentSpace.html",
					"UTF-8");
			String str;
			while ((str = br.readLine()) != null) {
				if (str.contains("<a href=\"file:")) {
					String code = str.substring(str.indexOf("<a href=\"file:"),
							str.indexOf("\">"));
					if (code.contains("Chapter")) {
						str = str.replace(code, "TempNumber");
					} else {
						str = str.replace(code, "TempLine");
					}
				}
				if (str.contains("<a href=\"#")) {
					if (str.contains("<a href=\"#")) {
						String code2 = str.substring(
								str.indexOf("<a href=\"#"), str.indexOf("\">"));
						if (code2.contains("Chapter")) {
							str = str.replace(code2, "TempNumber");
						} else {
							str = str.replace(code2, "TempLine");
						}
					}
				}
				writer.println(str);
			}
			br.close();
			writer.close();
			System.out
					.println("Temp content with space is ready!Program can continue now.");
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
	}

	public void FixAllLinks() {
		try {
			File fileDir2 = new File(
					"C:\\Project\\Links\\EnCSharpAll\\FoundLinks.txt");
			BufferedReader br2 = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir2), "UTF8"));
			PrintWriter writer = new PrintWriter(
					"C:\\Project\\Links\\EnCSharpAll\\FixedLinks.txt", "UTF-8");
			String str;
			while ((str = br2.readLine()) != null) {
				if (Pattern
						.compile(Pattern.quote("test"),
								Pattern.CASE_INSENSITIVE).matcher(str).find()) {
					Pattern pattern = Pattern.compile("///(.*?)/#");
					Matcher matcher = pattern.matcher(str);
					while (matcher.find()) {
						str = str.replaceAll("///(.*?)/#",
								"/english-intro-csharp-book/read-online/#");
						writer.println(str);
					}
				}
			}
			br2.close();
			writer.close();
			System.out.println("Links are fixed!Program can continue now.");
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
	}

	public void FixNumbers() {
		try {
			File fileDir2 = new File(
					"C:\\Project\\Links\\EnCSharpAll\\FixedLinks.txt");
			BufferedReader br2 = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir2), "UTF8"));
			PrintWriter writer = new PrintWriter(
					"C:\\Project\\Links\\EnCSharpAll\\FixedNumbers.txt",
					"UTF-8");
			PrintWriter writer2 = new PrintWriter(
					"C:\\Project\\Links\\EnCSharpAll\\FixLinesPreFinal.txt",
					"UTF-8");
			String str;
			while ((str = br2.readLine()) != null) {
				if (str.contains("/#")) {
					if (str.contains("Chapter")) {
						Pattern pattern = Pattern.compile("(\\d+)_");
						Matcher matcher = pattern.matcher(str);
						while (matcher.find()) {
							writer.println(matcher.group().replace("_", ""));
						}
					} else {
						String temp = str.substring(str.indexOf("/"),
								str.indexOf("#"));
						str = str.replace(temp, "");
						writer2.println(str);
					}
					if (str.contains("_Chapter_")) {
						Pattern pattern = Pattern.compile("(\\d+).");
						Matcher matcher = pattern.matcher(str);
						while (matcher.find()) {
							writer.println(matcher.group().replace(".", ""));
						}
					}
				}
			}
			br2.close();
			writer.close();
			writer2.close();
			System.out
					.println("Numbers and lines are done!Program can continue now.");
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
	}

	public void FixLinesFinal() {
		Vector<String> lineArray = new Vector<String>();
		String lineContents = null;
		try {
			File fileDir = new File(
					"C:\\Project\\Links\\EnCSharpAll\\FixLinesPreFinal.txt");

			BufferedReader br = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir), "UTF8"));
			while ((lineContents = br.readLine()) != null) {
				lineArray.add(lineContents);
			}
			br.close();
			PrintWriter writer = new PrintWriter(
					"C:\\Project\\Links\\EnCSharpAll\\FixLines.txt", "UTF-8");
			for (int i = 0; i < lineArray.size(); i++) {
				File fileDir2 = new File(
						"C:\\Project\\Links\\EnCSharpAll\\FixedExternal.txt");
				BufferedReader br2 = new BufferedReader(new InputStreamReader(
						new FileInputStream(fileDir2), "UTF8"));
				String str;
				while ((str = br2.readLine()) != null) {
					if (str.contains(lineArray.get(i))) {
						writer.println(str);
						break;
					}
				}
				br2.close();
			}
			writer.close();
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
	}

	public void GetNumbers() {
		Vector<String> lineArray = new Vector<String>();
		String lineContents = null;
		try {
			File fileDir = new File(
					"C:\\Project\\Links\\EnCSharpAll\\CSharpStrings.txt");

			BufferedReader br = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir), "UTF8"));
			while ((lineContents = br.readLine()) != null) {
				lineArray.add(lineContents);
			}
			br.close();
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}

		Vector<String> numberArray = new Vector<String>();
		String numberContents = null;
		try {
			File fixedN = new File(
					"C:\\Project\\Links\\EnCSharpAll\\FixedNumbers.txt");
			BufferedReader num = new BufferedReader(new InputStreamReader(
					new FileInputStream(fixedN), "UTF8"));
			while ((numberContents = num.readLine()) != null) {
				numberArray.add(numberContents);
			}
			num.close();
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
		try {
			PrintWriter writer = new PrintWriter(
					"C:\\Project\\Links\\EnCSharpAll\\TempLinks.txt", "UTF-8");
			for (int i = 0; i < numberArray.size(); i++) {

				writer.println(lineArray.get(Integer.parseInt(numberArray
						.get(i)) - 1));
			}
			writer.close();
			System.out
					.println("Numbers are converted!Program can continue now.");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}

	public void FinalStrings() {
		Vector<String> lineArray = new Vector<String>();
		String lineContents = null;
		try {
			File fileDir = new File(
					"C:\\Project\\Links\\EnCSharpAll\\TempLinks.txt");

			BufferedReader br = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir), "UTF8"));
			while ((lineContents = br.readLine()) != null) {
				lineArray.add(lineContents);
			}
			br.close();
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
		try {
			File fileDir = new File(
					"C:\\Project\\Links\\EnCSharpAll\\FixedLinks.txt");
			BufferedReader br2 = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir), "UTF8"));
			PrintWriter writer = new PrintWriter(
					"C:\\Project\\Links\\EnCSharpAll\\FinalStrings.txt",
					"UTF-8");
			String str;
			int i = 0;
			while ((str = br2.readLine()) != null) {
				if (str.contains("/#")) {
					if (str.contains("Chapter")) {
						String code = str.substring(str.indexOf("/#"));
						str = str.replace(code, "/" + lineArray.get(i));
						writer.println(str);
						i++;
					}
				}
			}
			br2.close();
			writer.close();
			System.out
					.println("Final string is done!Program can continue now.");
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
	}

	public void FinalContent() {
		Vector<String> numArray = new Vector<String>();
		String numContents = null;
		try {
			File numDir = new File(
					"C:\\Project\\Links\\EnCSharpAll\\FinalStrings.txt");

			BufferedReader numBr = new BufferedReader(new InputStreamReader(
					new FileInputStream(numDir), "UTF8"));
			while ((numContents = numBr.readLine()) != null) {
				numArray.add(numContents);
			}
			numBr.close();
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
		Vector<String> lineArray = new Vector<String>();
		String lineContents = null;
		try {
			File lineDir = new File(
					"C:\\Project\\Links\\EnCSharpAll\\FixLines.txt");

			BufferedReader lineBr = new BufferedReader(new InputStreamReader(
					new FileInputStream(lineDir), "UTF8"));
			while ((lineContents = lineBr.readLine()) != null) {
				lineArray.add(lineContents);
			}
			lineBr.close();
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
		try {
			File fileDir = new File(
					"C:\\Project\\Links\\EnCSharpAll\\TempContentSpace.html");
			BufferedReader br = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir), "UTF8"));
			PrintWriter writer = new PrintWriter(
					"C:\\Project\\Links\\EnCSharpAll\\FinalContent.html",
					"UTF-8");
			String str;
			int i = 0;
			int c = 0;
			while ((str = br.readLine()) != null) {
				if (str.contains("TempNumber")) {
					String code = str.substring(str.indexOf("TempNumber"),
							str.indexOf("\">"));
					str = str.replace(code, "<a href=\"" + numArray.get(i));
					i++;
				} else {
					if (str.contains("TempLine")) {
						String code = str.substring(str.indexOf("TempLine"),
								str.indexOf("\">"));
						str = str
								.replace(code, "<a href=\"" + lineArray.get(c));
						c++;
					}
				}
				writer.write(str);
			}
			br.close();
			writer.close();
			System.out
					.println("Final content is ready to be used!Program can continue now.");
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
	}

	@SuppressWarnings("resource")
	public boolean checkForErrors() {
		try {
			File fileDir = new File(
					"C:\\Project\\Links\\EnCSharpAll\\ErrorCheck.txt");
			BufferedReader in = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir), "UTF8"));

			String str;
			while ((str = in.readLine()) != null) {
				if (str.contains("String index out of range")
						|| str.contains("null")
						|| str.contains("Array index out of range")) {
					return false;
				}
			}
			if (globalFlag == 0) {
				return false;
			}
			in.close();
		} catch (UnsupportedEncodingException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return true;
	}
}
