package fixCSharpENLinks;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ReplaceAname {
	public void putInFile() {
		Vector<String> lineArray = new Vector<String>();
		String lineContents = null;
		try {
			File fileDir2 = new File("C:\\Project\\Links\\EnCSharp\\postName.txt");

			BufferedReader br = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir2), "UTF8"));
			while ((lineContents = br.readLine()) != null) {
				lineArray.add(lineContents);
			}
			br.close();
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
		try {
			File fileDir = new File("C:\\Project\\Links\\EnCSharp\\EnContent.html");
			BufferedReader in = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir), "UTF8"));

			String str;
			FileOutputStream file = new FileOutputStream(
					"C:\\Project\\Links\\EnCSharp\\Aname.txt", true);
			BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(
					file, "UTF8"));
			while ((str = in.readLine()) != null) {
				if (str.contains("<a name=\"")) {
					Pattern pattern = Pattern.compile("<a name=\"(.*?)\">");
					Matcher matcher = pattern.matcher(str);
					while(matcher.find()) {
						writer.write(lineArray.get(0) + matcher.group(1) + "\n");
					}
				}
			}
			writer.write("\n");
			writer.close();
			in.close();
			System.out.println("Links added successfully!");
		} catch (UnsupportedEncodingException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
