package mindMapsGenerator;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;

public class MindMaps {

	public static void main(String[] args) throws IOException {
		String maps = "/wp-content/uploads/2013/07/MindMaps/";
		try {
			for (int i = 1; i <= 27; i++) {
				FileOutputStream file = new FileOutputStream(
						"C:\\Project\\MindMaps\\en-mozilla\\"+i+".html");
				BufferedWriter writer = new BufferedWriter(
						new OutputStreamWriter(file, "UTF8"));
				File folder = new File(
						"C:\\xampp\\htdocs\\Project\\wp-content\\uploads\\2013\\07\\MindMaps\\");
				File[] listOfFiles = folder.listFiles();
				int j = 0;
				/*writer.write("var marker "+i+" = new google.maps.Marker({\n" +
					"position: new google.maps.LatLng(0,0),\n"+
					"map: map,\n"+
					"title: 'Chapter "+i+"'\n"+
					"});\n"+  
					"google.maps.event.addListener(marker"+i+", 'click', function() {\n"+
					"triggerClickById('mindMap"+i+"');\n"+
					"});\n");*/
				/*writer.write("<div id=\"group" + i
						+ "\" style=\"display: none\" >\n");*/
				writer.write("<div class=\"thumbsContainer\">");
				for (int z = 0; z < listOfFiles.length; z++) {
					String suffix = ".html";
					String suffix2 = "bg.html";
					String temp;
					if (i < 10) {
						temp = "0" + i;
					} else {
						temp = Integer.toString(i);
					}
					if (listOfFiles[z].getName().toLowerCase().endsWith(suffix)
							&& listOfFiles[z].getName().startsWith(temp)
							&& (listOfFiles[z].getName().toLowerCase()
									.endsWith(suffix2) == false)) {
						j++;
						String jemp;
						if (j < 10) {
							jemp = "0" + j;
						} else {
							jemp = Integer.toString(j);
						}
						if (j == 1) {
							writer.write("<a class=\"fancybox-thumb fancybox.iframe \" rel=\"fancybox-thumb"
									+ i
									+ "\" href=\""
									+ maps
									+ temp
									+ " v"
									+ jemp
									+ ".html\" title=\"Chapter "
									+ i
									+ "\">"
									+ "<img class=\"myframe\" src=\""
									+ maps
									+ temp
									+ " v"
									+ jemp
									+ "-tiles/t.jpg\" alt=\"\" />" + "</a>");
						} else {
							writer.write("<a class=\"fancybox-thumb fancybox.iframe \" rel=\"fancybox-thumb"
									+ i
									+ "\" href=\""
									+ maps
									+ temp
									+ " v"
									+ jemp
									+ ".html\" title=\"Chapter "
									+ i
									+ "\">"
									+ "<img class=\"myframe\" src=\""
									+ maps
									+ temp
									+ " v"
									+ jemp
									+ "-tiles/t.jpg\" alt=\"\" />" + "</a>");
						}
					}
				}
				writer.write("</div>");
				writer.close();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}
}
