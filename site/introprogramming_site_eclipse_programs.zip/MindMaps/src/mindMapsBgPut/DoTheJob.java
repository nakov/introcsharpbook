package mindMapsBgPut;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Vector;

public class DoTheJob {
	public static void main(String[] args) throws IOException {
		getID getid = new getID();
		getid.getID();
		Vector<String> lineArray = new Vector<String>();
		String lineContents = null;
		try {
			File fileDir2 = new File("C:\\Project\\MindMaps\\bg-mozilla\\ID.txt");

			BufferedReader br = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir2), "UTF8"));
			while ((lineContents = br.readLine()) != null) {
				lineArray.add(lineContents);
			}
			br.close();
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
		for (int i = 1; i <= lineArray.size(); i++) {
			getContent getCont = new getContent();
			getCont.getCont(lineArray.get(i - 1));
			PutMaps putM = new PutMaps();
			putM.putMaps(i);
			putContent putCont = new putContent();
			putCont.putCont(lineArray.get(i - 1));
		}
	}
}
