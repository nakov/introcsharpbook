package mindMapsBgPut;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.Vector;

public class PutMaps {
	public void putMaps(int i) throws IOException {
		try {
			Vector<String> lineArray = new Vector<String>();
			String lineContents = null;
			File fileDir2 = new File("C:\\Project\\MindMaps\\bg-mozilla\\" + i
					+ ".html");

			BufferedReader br;

			br = new BufferedReader(new InputStreamReader(new FileInputStream(
					fileDir2), "UTF8"));

			while ((lineContents = br.readLine()) != null) {
				lineArray.add(lineContents);
			}
			br.close();

			File fileDir = new File("C:\\Project\\MindMaps\\bg-mozilla\\rltest.html");
			BufferedReader in = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir), "UTF8"));

			PrintWriter writer = new PrintWriter(
					"C:\\Project\\MindMaps\\bg-mozilla\\WithMaps.html", "UTF-8");
			String str;
			int count = 0;
			while ((str = in.readLine()) != null) {
				if (str.contains("<div class=\"thumbsContainer\">") && count == 0) {
					str = str.replaceAll("<div class=\"thumbsContainer\">(.*?)</a></div>",lineArray.get(0));
					count = 1;
				}
				writer.write(str);
			}
			writer.close();
			in.close();
			System.out.println("No errors found and can continue!");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
}