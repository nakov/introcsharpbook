package allChsarpBG;

import java.awt.Color;
import java.awt.Container;
import java.awt.GridBagLayout;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.WindowConstants;

public class GetName {
	public void getChapter(String i) {
		String driverName = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://localhost/";

		String dbName = "nakovorg_new_introprogramming?useUnicode=true&characterEncoding=utf-8";
		String userName = "root";
		String password = "";

		Connection con;
		Statement stmt;
		try {
			Class.forName(driverName).newInstance();
			con = DriverManager.getConnection(url + dbName, userName, password);
			try {
				stmt = con.createStatement();
				FileOutputStream file = new FileOutputStream(
						"C:\\Project\\Links\\CsharpBGAll\\postName.txt", false);
				BufferedWriter writer = new BufferedWriter(
						new OutputStreamWriter(file, "UTF8"));
				String query = "SELECT post_name FROM `posts` WHERE ID = '" + i +"'";
				ResultSet rs = stmt.executeQuery(query);
				while (rs.next()) {
					String postName = rs.getString("post_name");
					writer.write("/intro-csharp-book/read-online/" + postName + "/#");
				}
				stmt.close();
				writer.close();
			} catch (SQLException s) {
				JFrame f = new JFrame("Selecting error!");
				f.setSize(400, 150);
				f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
				Container content = f.getContentPane();
				content.setBackground(Color.white);
				content.setLayout(new GridBagLayout());
				content.add(new JLabel("An error occured while selecting!"));
				f.setLocationRelativeTo(null);
				f.setVisible(true);
				s.printStackTrace();
			}

			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
