package postToPage;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

public class NoNewLines {
	public void NoNewLines() {
		try {
			PrintWriter writer = new PrintWriter(
					"C:\\Project\\Posts\\PostContentNoLines.html", "UTF-8");
			File fileDir = new File("C:\\Project\\Posts\\PostContent.html");

			BufferedReader br = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir), "UTF8"));
			String str;
			try {
				while ((str = br.readLine()) != null) {
					writer.write(str);
				}
				br.close();
				writer.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
