package postToPage;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Vector;

public class MakeAll {
	public static void main(String[] args) {
		GetPost getPost = new GetPost();
		getPost.getTitle();
		Vector<String> lineArray = new Vector<String>();
		String lineContents = null;
		try {
			File fileDir = new File("C:\\Project\\Posts\\Title.txt");

			BufferedReader br = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir), "UTF8"));
			while ((lineContents = br.readLine()) != null) {
				lineArray.add(lineContents);
			}
			br.close();
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
		for (int i = 0; i < lineArray.size(); i++) {
			ReadFromFile readFrom = new ReadFromFile();
			readFrom.readFromFile(lineArray.get(i));
			NoNewLines noNewLines = new NoNewLines();
			noNewLines.NoNewLines();
			PutPage putPage = new PutPage();
			putPage.putIn(lineArray.get(i));
		}
	}
}
