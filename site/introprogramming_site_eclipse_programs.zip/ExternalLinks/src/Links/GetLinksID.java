package Links;

import java.awt.Color;
import java.awt.Container;
import java.awt.GridBagLayout;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.WindowConstants;

public class GetLinksID {
	public void getID() {
		String driverName = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://localhost/";

		String dbName = "test?useUnicode=true&characterEncoding=utf-8";
		String userName = "root";
		String password = "";

		Connection con;
		Statement stmt;
		try {
			Class.forName(driverName).newInstance();
			con = DriverManager.getConnection(url + dbName, userName, password);
			try {
				PrintWriter writer = new PrintWriter("C:\\Project\\CSharpEn\\ID.txt",
						"UTF-8");
				stmt = con.createStatement();
				String query = "SELECT ID FROM posts WHERE post_content LIKE '%file:%' AND (guid LIKE '%intro-csharp-book/read-online/%' OR guid LIKE '%intro-java-book/read-online/%' OR guid LIKE '%english-intro-csharp-book/read-online/%') AND (post_title LIKE '%Глава%' OR post_title LIKE '%Chapter%') ";
				ResultSet rs = stmt.executeQuery(query);
				while (rs.next()) {
					Integer postContent = rs.getInt("ID");
					writer.println(postContent);
				}
				stmt.close();
				writer.close();

			} catch (SQLException s) {
				JFrame f = new JFrame("Getting ID error!");
				f.setSize(400, 150);
				f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
				Container content = f.getContentPane();
				content.setBackground(Color.white);
				content.setLayout(new GridBagLayout());
				content.add(new JLabel(
						"An error occured while getting ID.Check your table and come back!"));
				f.setLocationRelativeTo(null);
				f.setVisible(true);
				s.printStackTrace();
			}

			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
