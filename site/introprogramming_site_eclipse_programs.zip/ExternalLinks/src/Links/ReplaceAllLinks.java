package Links;

import java.awt.Color;
import java.awt.Container;
import java.awt.GridBagLayout;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.WindowConstants;

public class ReplaceAllLinks {
	public static void main(String[] args) {
	/*	GetLinksID getId = new GetLinksID();
		getId.getID();
		Vector<String> lineArray = new Vector<String>();
		String lineContents = null;
		try {
			File fileDir2 = new File("C:\\Project\\CSharpEn\\ID.txt");

			BufferedReader br = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir2), "UTF8"));
			while ((lineContents = br.readLine()) != null) {
				lineArray.add(lineContents);
			}
			br.close();
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
		for (int i = 0; i < lineArray.size(); i++) {
			try {
				FileOutputStream fos = new FileOutputStream(
						"C:\\Project\\CSharpEn\\ErrorCheck.txt");
				PrintStream out = new PrintStream(fos);
				System.setOut(out);

			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
			GetLinksContent getcont = new GetLinksContent();
			getcont.getLinks(lineArray.get(i));
			InsertAllLinks insertIn = new InsertAllLinks();
			if (insertIn.checkForContent() == false) {
				JFrame f = new JFrame("Already updated!");
				f.setSize(400, 150);
				f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
				Container content = f.getContentPane();
				content.setBackground(Color.white);
				content.setLayout(new GridBagLayout());
				content.add(new JLabel(
						"The program has already updated this file with ID "
								+ lineArray.get(i) + "!"));
				f.setLocationRelativeTo(null);
				f.setVisible(true);
			} else {
				PutLinksContent putcont = new PutLinksContent();
				insertIn.insertLine();
				insertIn.getWithSpaces();
				insertIn.printContent();
				insertIn.printLast();
				insertIn.fixCode();
				putcont.putCont(lineArray.get(i));
				if (insertIn.checkForErrors() == true) {
					JFrame f = new JFrame("Done!");
					f.setSize(500, 150);
					f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
					Container content = f.getContentPane();
					content.setBackground(Color.white);
					content.setLayout(new GridBagLayout());
					content.add(new JLabel(
							"The program has finished successfully!Content with ID "
									+ lineArray.get(i) + " is ready."));
					f.setLocationRelativeTo(null);
					f.setVisible(true);
				} else {
					JFrame f = new JFrame("Error found!");
					f.setSize(550, 150);
					f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
					Container content = f.getContentPane();
					content.setBackground(Color.white);
					content.setLayout(new GridBagLayout());
					content.add(new JLabel(
							"Sorry the program has encountered an error!This ID failed "
									+ lineArray.get(i) + "!"));
					f.setLocationRelativeTo(null);
					f.setVisible(true);
					PutLinksRealContent realContent = new PutLinksRealContent();
					realContent.putBackRealCont(lineArray.get(i));
				}
			}
		}*/
		GetStrings getstr = new GetStrings();
		getstr.getCSharp();
	}
}
