package javaLinks;

import java.awt.Color;
import java.awt.Container;
import java.awt.GridBagLayout;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.WindowConstants;

public class ChangeJavaLinks {
	public static void main(String[] args) {
		GetJavaStrings getStrings = new GetJavaStrings();
		getStrings.getJavaStrings();
		GetJavaID getId = new GetJavaID();
		getId.getJavaID();
		Vector<String> lineArray = new Vector<String>();
		String lineContents = null;
		try {
			File fileDir2 = new File("C:\\Project\\Links\\Java\\JavaID.txt");

			BufferedReader br = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir2), "UTF8"));
			while ((lineContents = br.readLine()) != null) {
				lineArray.add(lineContents);
			}
			br.close();
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
		for (int i = 0; i < lineArray.size(); i++) {
			try {
				FileOutputStream fos = new FileOutputStream(
						"C:\\Project\\Links\\Java\\ErrorCheck.txt");
				PrintStream out = new PrintStream(fos);
				System.setOut(out);

			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
			GetJavaContent JavaLinks = new GetJavaContent();
			JavaLinks.GetJavaContent(lineArray.get(i));
			FixJavaLinks getLinksFrom = new FixJavaLinks();
			getLinksFrom.GetLinks();
			getLinksFrom.TempContent();
			getLinksFrom.TempContentSpace();
			getLinksFrom.FixAllLinks();
			getLinksFrom.FixNumbers();
			getLinksFrom.GetNumbers();
			getLinksFrom.FinalStrings();
			getLinksFrom.FinalContent();
			if (getLinksFrom.checkForErrors() == true) {
				PutBackLinks putBack = new PutBackLinks();
				putBack.putCont(lineArray.get(i));
				JFrame f = new JFrame("Done!");
				f.setSize(500, 150);
				f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
				Container content = f.getContentPane();
				content.setBackground(Color.white);
				content.setLayout(new GridBagLayout());
				content.add(new JLabel(
						"The program has finished successfully!Content with ID "
								+ lineArray.get(i) + " is ready."));
				f.setLocationRelativeTo(null);
				f.setVisible(true);
			} else {
				JFrame f = new JFrame("Error found!");
				f.setSize(550, 150);
				f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
				Container content = f.getContentPane();
				content.setBackground(Color.white);
				content.setLayout(new GridBagLayout());
				content.add(new JLabel(
						"Sorry the program has encountered an error!This ID failed "
								+ lineArray.get(i) + "!"));
				f.setLocationRelativeTo(null);
				f.setVisible(true);
				PutRealJavaContent realContent = new PutRealJavaContent();
				realContent.putBackRealCont(lineArray.get(i));
			}
		}
	}
}
