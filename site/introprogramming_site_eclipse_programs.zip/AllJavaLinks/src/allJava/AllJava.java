package allJava;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Vector;

public class AllJava {

	public static void main(String[] args) {
		GetID getId = new GetID();
		getId.getEnID();
		Vector<String> lineArray = new Vector<String>();
		String lineContents = null;
		try {
			File fileDir2 = new File("C:\\Project\\Links\\JavaAll\\ID.txt");

			BufferedReader br = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir2), "UTF8"));
			while ((lineContents = br.readLine()) != null) {
				lineArray.add(lineContents);
			}
			br.close();
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
		for (int i = 0; i <= lineArray.size(); i++) {
			GetContent getCont = new GetContent();
			getCont.GetEnContent(lineArray.get(i));
			GetName getName = new GetName();
			getName.getChapter(lineArray.get(i));
			Links replaceName = new Links();
			replaceName.putInFile();
		}
	}

}
