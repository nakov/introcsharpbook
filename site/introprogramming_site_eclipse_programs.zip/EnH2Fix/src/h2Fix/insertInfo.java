package h2Fix;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class insertInfo {
	int globalFlag = 0;

	@SuppressWarnings("resource")
	public boolean checkForContent() {
		try {
			File fileDir = new File("C:\\Project\\enBook\\rltest.html");
			BufferedReader in = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir), "UTF8"));

			String str;
			PrintWriter writer = new PrintWriter(
					"C:\\Project\\enBook\\withSpace.html", "UTF-8");
			while ((str = in.readLine()) != null) {
				if (str.contains("<h2 id=\"table-of-contents\" style=\"margin: 12pt 0cm 6pt;\"><span  style=\"font-family: Verdana; font-size: 14pt; color: #000000; font-weight: bold;\">Content</span></h2>")) {
					return false;
				}
			}
			writer.close();
			in.close();
			System.out.println("No errors found and can continue!");
		} catch (UnsupportedEncodingException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return true;
	}

	public void insertLine() {
		try {
			File fileDir = new File("C:\\Project\\enBook\\rltest.html");
			BufferedReader in = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir), "UTF8"));

			String str;
			PrintWriter writer = new PrintWriter(
					"C:\\Project\\enBook\\withSpace.html", "UTF-8");
			while ((str = in.readLine()) != null) {
				if (str.contains("<div class=\"WordSection1\">")) {
					String code = str.substring(str.indexOf("<div"),
							str.indexOf("WordSection1\">"));
					str = str.replace(code, "");
					str = str.replace("WordSection1\">", "");
					globalFlag = 1;
				}
				if (str.contains("<p class=\"MsoNormal\" style=\"page-break-after: avoid; margin: 12pt 0in 6pt; mso-outline-level: 2\" align=\"left\">")) {
					Pattern pattern = Pattern
							.compile("<p(.*?)mso-outline-level: 2\" align=\"left\">");
					Matcher matcher = pattern.matcher(str);
					matcher.find();
					String newline = System.getProperty("line.separator");
					str = str.replace("<p", "");
					str = str.replace(matcher.group(1), newline + "<p"
							+ matcher.group(1));
					str = str.replaceFirst("\n", "");
					writer.println(str);
				}
			}
			writer.close();
			in.close();
			System.out.println("New line added successfully!");
		} catch (UnsupportedEncodingException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public void getWithSpaces() {

		try {
			File fileDir = new File("C:\\Project\\enBook\\withSpace.html");

			BufferedReader in = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir), "UTF8"));

			String str;
			PrintWriter writer = new PrintWriter(
					"C:\\Project\\enBook\\done3.html", "UTF-8");
			writer.println("<h2 id=\"table-of-contents\" style=\"margin: 12pt 0cm 6pt;\"><span  style=\"font-family: Verdana; font-size: 14pt; color: #000000; font-weight: bold;\">Content</span></h2>"
					+ "\n<ul>"
					+ "\n<li><a href=\"#video-lesson\">Video</a></li>"
					+ "\n<li><a href=\"#presentation-slides\">Presentation</a></li>"
					+ "\n<li><a href=\"#mind-maps\">Mind maps</a></li>");
			while ((str = in.readLine()) != null) {
				if (str.contains("<p class=\"MsoNormal\" style=\"page-break-after: avoid; margin: 12pt 0in 6pt; mso-outline-level: 2\" align=\"left\">")) {
					String code = str.substring(str.indexOf("<p"),
							str.indexOf("<a name=\"_"));
					str = str.replace(code, " ");
					str = str.replace("<a name=\"_", "");
					String code2 = str.substring(str.indexOf(" "),
							str.indexOf("\">"));
					code2 = code2.replace(" ", "");
					writer.print("<li><a href=\"#_" + code2 + "\">");
				}

				if (str.contains("<font style=\"font-size: 14pt\" color=\"#000000\">")) {
					Pattern p = Pattern.compile("color=\"#000000\">(.*?)</font>");
					Matcher m = p.matcher(str);

					while (m.find()) {
						writer.print(m.group(1));
					}
					writer.print("</a></li>");
					writer.print("\n");
				} else {
					if (str.contains("<font style=\"font-size: 14pt\">")) {
						Pattern p = Pattern.compile("style=\"font-size: 14pt\">(.*?)</font>");
						Matcher m = p.matcher(str);

						while (m.find()) {
							writer.print(m.group(1));
						}
						writer.print("</a></li>");
						writer.print("\n");
					}
				}
			}
			writer.println("<li><a href=\"#demos-source-code\">Demonstrations (source code)</a></li>"
					+ "\n<li><a href=\"#discussion-forum\">Discussion forum</a></li>"
					+ "\n</ul>");
			writer.println("<h2 id=\"video-lesson\" style=\"margin: 12pt 0cm 6pt;\"><span style=\"font-family: Verdana; font-size: 14pt; color: #000000; font-weight: bold;\">Video</span></h2>"
					+ "<iframe src=\"//www.youtube.com/\" height=\"540\" width=\"720\" allowfullscreen=\"\" frameborder=\"0\"></iframe>"
					+ "<h2 id=\"presentation-slides\" style=\"margin: 12pt 0cm 6pt;\"><span  style=\"font-family: Verdana; font-size: 14pt; color: #000000; font-weight: bold;\">Presentation</span></h2>"
					+ "<iframe src=\"http://www.slideshare.net/\" height=\"578\" width=\"720\" frameborder=\"0\" marginwidth=\"0\" marginheight=\"0\" scrolling=\"no\"></iframe>"
					+ "<h2 id=\"mind-maps\" style=\"margin: 12pt 0cm 6pt;\"><span  style=\"font-family: Verdana; font-size: 14pt; color: #000000; font-weight: bold;\">Mind maps</span></h2>"
					+ "...");
			writer.close();
			in.close();
			System.out
					.println("The content from the file was taken successfully!");
		} catch (UnsupportedEncodingException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public void printContent() {
		Vector<String> lineArray = new Vector<String>();
		String lineContents = null;
		try {
			File fileDir2 = new File("C:\\Project\\enBook\\done3.html");

			BufferedReader br = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir2), "UTF8"));
			while ((lineContents = br.readLine()) != null) {
				lineArray.add(lineContents);
			}
			br.close();
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}
		try {
			File fileDir = new File("C:\\Project\\enBook\\rltest.html");

			PrintWriter writer = new PrintWriter(
					"C:\\Project\\enBook\\Info.html", "UTF-8");
			BufferedReader in = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir), "UTF8"));

			String str;
			str = in.readLine();
			int count = 0;
			int flag = 0;
			while (flag == 1) {
				if (str.contains("<div class=\"WordSection1\">")) {
					String code = str.substring(str.indexOf("<div"),
							str.indexOf("WordSection1\">"));
					str = str.replace(code, "");
					str = str.replace("WordSection1\">", "");
					writer.write(str);
					flag = 1;
					globalFlag = 1;
				}
			}
			do {
				if (str.contains("</font></font></span></p> <p class=\"MsoNormal\" style=\"page-break-after: avoid; margin: 12pt 0in 6pt; mso-outline-level: 2\" align=\"left\">")) {
					String code = str.substring(str.indexOf("<"),
							str.indexOf("</font></font></span></p> <p class=\"MsoNormal\" style=\"page-break-after: avoid; margin: 12pt 0in 6pt; mso-outline-level: 2\" align=\"left\">"));
					writer.write(code);
					count = 1;
				}
			} while ((str == "</font></font></span></p> <p class=\"MsoNormal\" style=\"page-break-after: avoid; margin: 12pt 0in 6pt; mso-outline-level: 2\" align=\"left\">") && (count == 1));

			for (int i = 0; i < lineArray.size(); i++) {
				writer.write(lineArray.get(i));
			}
			do {
				if (str.contains("</font></font></span></p> <p class=\"MsoNormal\" style=\"page-break-after: avoid; margin: 12pt 0in 6pt; mso-outline-level: 2\" align=\"left\">")) {
					String code = str.substring(str.indexOf("</font></font></span></p> <p class=\"MsoNormal\" style=\"page-break-after: avoid; margin: 12pt 0in 6pt; mso-outline-level: 2\" align=\"left\">"));
					writer.write(code);
				}
			} while ((str == null) && (count == 1));
			writer.close();
			in.close();
			System.out.println("Content printed successfully!");
		} catch (UnsupportedEncodingException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public void printLast() {
		try {
			File fileDir = new File("C:\\Project\\enBook\\Info.html");

			PrintWriter writer = new PrintWriter(
					"C:\\Project\\enBook\\withInfo.html", "UTF-8");
			BufferedReader in = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir), "UTF8"));
			String str;
			int finalRow = 0;
			while ((str = in.readLine()) != null) {
				if (!str.contains("<h2 id=\"demos-source-code\" style=\"margin: 12pt 0cm 6pt;\"><span  style=\"font-family: Verdana; font-size: 14pt; color: #000000; font-weight: bold;\">Demonstrations (source code)</span></h2>"
						+ "<span style=\"font-family: Verdana; font-size: 10pt;\">Download the demo examples for this chapter from the book: <a href=\"#\">demos.zip</a>.</span>"
						+ "\n<h2 id=\"discussion-forum\" style=\"margin: 12pt 0cm 6pt;\"><span  style=\"font-family: Verdana; font-size: 14pt; color: #000000; font-weight: bold;\">Discussion forum</span></h2>"
						+ "<span style=\"font-family: Verdana; font-size: 10pt;\">Comment the book and the tasks in the : <a href=\"http://forums.academy.telerik.com\" target=\"_blank\">forum of the Software Academy</a>.</span>")) {
					if (str.contains("</div>") && globalFlag == 1) {
						StringBuilder b = new StringBuilder(str);
						b.replace(
								str.lastIndexOf("</div>"),
								str.lastIndexOf("</div>") + 6,
								"<h2 id=\"demos-source-code\" style=\"margin: 12pt 0cm 6pt;\"><span  style=\"font-family: Verdana; font-size: 14pt; color: #000000; font-weight: bold;\">Demonstrations (source code)</span></h2>"
										+ "<span style=\"font-family: Verdana; font-size: 10pt;\">Download the demo examples for this chapter from the book: <a href=\"#\">demos.zip</a>.</span>"
										+ "\n<h2 id=\"discussion-forum\" style=\"margin: 12pt 0cm 6pt;\"><span  style=\"font-family: Verdana; font-size: 14pt; color: #000000; font-weight: bold;\">Discussion forum</span></h2>"
										+ "<span style=\"font-family: Verdana; font-size: 10pt;\">Comment the book and the tasks in the : <a href=\"http://forums.academy.telerik.com\" target=\"_blank\">forum of the Software Academy</a>.</span>"
										+ "</div>");
						str = b.toString();
						writer.println(str);
						finalRow = 0;
					} else {
						finalRow = 1;
						writer.println(str);
					}
				}

			}
			if (finalRow == 1) {
				writer.println("<h2 id=\"demos-source-code\" style=\"margin: 12pt 0cm 6pt;\"><span  style=\"font-family: Verdana; font-size: 14pt; color: #000000; font-weight: bold;\">Demonstrations (source code)</span></h2>"
						+ "<span style=\"font-family: Verdana; font-size: 10pt;\">Download the demo examples for this chapter from the book: <a href=\"#\">demos.zip</a>.</span>"
						+ "\n<h2 id=\"discussion-forum\" style=\"margin: 12pt 0cm 6pt;\"><span  style=\"font-family: Verdana; font-size: 14pt; color: #000000; font-weight: bold;\">Discussion forum</span></h2>"
						+ "<span style=\"font-family: Verdana; font-size: 10pt;\">Comment the book and the tasks in the : <a href=\"http://forums.academy.telerik.com\" target=\"_blank\">forum of the Software Academy</a>.</span>");
			}
			writer.close();
			in.close();
			System.out.println("Last line added successfully!");
		} catch (UnsupportedEncodingException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public void fixCode() {
		try {
			File fileDir = new File("C:\\Project\\enBook\\withInfo.html");
			BufferedReader in = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir), "UTF8"));

			String str;
			PrintWriter writer = new PrintWriter(
					"C:\\Project\\enBook\\withInfoFinal.html", "UTF-8");
			while ((str = in.readLine()) != null) {
				String str2;
				str2 = "&nbsp;&nbsp;&nbsp";
				String str3;
				str3 = "<p style=\"margin: 0cm 0cm 0pt\" class=\"MsoNormal\" align=\"center\">";
				String str4;
				str4 = "width=\"712\"";
				String str5;
				str5 = "<p style=\"text-align:center;margin:0\">";
				if (str.contains("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp")) {
					str = str.replaceAll("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp", str2);
					System.out.println("Now we have 3 spaces");
				}
				if (str.contains("width=\"531\"")) {
					str = str.replaceAll("width=\"531\"", str4);
					System.out.println("Width 531 changed to 712");
				}
				if (str.contains("width=\"481\"")) {
					str = str.replaceAll("width=\"481\"", str4);
					System.out.println("Width 481 changed to 712");
				}
				if (str.contains("width=\"492\"")) {
					str = str.replaceAll("width=\"492\"", str4);
					System.out.println("Width 492 changed to 712");
				}
				if (str.contains("width=\"477\"")) {
					str = str.replaceAll("width=\"477\"", str4);
					System.out.println("Width 477 changed to 712");
				}
				if (str.contains(str3)) {
					str = str.replaceAll(str3, str5);
					System.out.println("It should be centered now");
				}
				if (str.contains("width=\"507\"")) {
					str = str.replaceAll("width=\"507\"", str4);
					System.out.println("Width 507 changed to 712");
				}
				if (str.contains("width=\"536\"")) {
					str = str.replaceAll("width=\"536\"", str4);
					System.out.println("Width 536 changed to 712");
				}
				if (str.contains("width=\"528\"")) {
					str = str.replaceAll("width=\"528\"", str4);
					System.out.println("Width 528 changed to 712");
				}
				if (str.contains("width=\"600\"")) {
					str = str.replaceAll("width=\"600\"", str4);
					System.out.println("Width 600 changed to 712");
				}
				if (str.contains("width=\"483\"")) {
					str = str.replaceAll("width=\"483\"", str4);
					System.out.println("Width 483 changed to 712");
				}
				if (str.contains("width=\"612\"")) {
					str = str.replaceAll("width=\"612\"", str4);
					System.out.println("Width 612 changed to 712");
				}
				if (str.contains("width=\"529\"")) {
					str = str.replaceAll("width=\"529\"", str4);
					System.out.println("Width 529 changed to 712");
				}
				if (str.contains("width=\"500\"")) {
					str = str.replaceAll("width=\"500\"", str4);
					System.out.println("Width 500 changed to 712");
				}
				if (str.contains("width=\"528\"")) {
					str = str.replaceAll("width=\"528\"", str4);
					System.out.println("Width 528 changed to 712");
				}
				if (str.contains("width=\"506\"")) {
					str = str.replaceAll("width=\"506\"", str4);
					System.out.println("Width 506 changed to 712");
				}
				if (str.contains("width=\"504\"")) {
					str = str.replaceAll("width=\"504\"", str4);
					System.out.println("Width 504 changed to 712");
				}
				if (str.contains("width=\"505\"")) {
					str = str.replaceAll("width=\"505\"", str4);
					System.out.println("Width 505 changed to 712");
				}
				if (str.contains("width=\"530\"")) {
					str = str.replaceAll("width=\"530\"", str4);
					System.out.println("Width 530 changed to 712");
				}
				if (str.contains("width=\"502\"")) {
					str = str.replaceAll("width=\"502\"", str4);
					System.out.println("Width 502 changed to 712");
				}
				writer.write(str);
			}
			writer.close();
			in.close();
			System.out.println("Code fixed successfully!\n");
		} catch (UnsupportedEncodingException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	@SuppressWarnings("resource")
	public boolean checkForErrors() {
		try {
			File fileDir = new File("C:\\Project\\enBook\\ErrorCheck.txt");
			BufferedReader in = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileDir), "UTF8"));

			String str;
			while ((str = in.readLine()) != null) {
				if (str.contains("String index out of range")
						|| str.contains("null")) {
					return false;
				}
			}
			in.close();
		} catch (UnsupportedEncodingException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return true;
	}
}